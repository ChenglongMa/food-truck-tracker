package mad.geo.model.interfaces;

import java.util.Date;

/**
 * GeoTracking
 *
 * @author : Charles Ma
 * @date : 30-08-2018
 * @time : 10:46
 * @description :
 */
public interface Tracking {


}
