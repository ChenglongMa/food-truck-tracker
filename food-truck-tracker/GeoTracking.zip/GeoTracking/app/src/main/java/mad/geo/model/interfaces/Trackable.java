package mad.geo.model.interfaces;

/**
 * GeoTracking
 *
 * @author : Charles Ma
 * @date : 30-08-2018
 * @time : 10:39
 * @description :
 */
public interface Trackable {

}
