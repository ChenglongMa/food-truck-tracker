package mad.geo.model;

/**
 * GeoTracking
 *
 * @author : Charles Ma
 * @date : 30-08-2018
 * @time : 11:46
 * @description :
 */
public class FoodTruck extends AbstractTrackable {

}
