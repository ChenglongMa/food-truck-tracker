package mad.geo.model;

/**
 * GeoTracking
 *
 * @author : Charles Ma
 * @date : 30-08-2018
 * @time : 11:48
 * @description :
 */
public class MealEvent extends AbstractTracking {

}
