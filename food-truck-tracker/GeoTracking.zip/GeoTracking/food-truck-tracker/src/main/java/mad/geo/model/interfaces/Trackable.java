package mad.geo.model.interfaces;

/**
 * The trackable interface
 */
public interface Trackable {

}
