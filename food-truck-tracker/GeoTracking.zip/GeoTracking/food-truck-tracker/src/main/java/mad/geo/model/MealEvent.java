package mad.geo.model;

/**
 * The concrete event of tracking
 */
public class MealEvent extends AbstractTracking {

}
