package mad.geo.model;

import java.util.Locale;

import mad.geo.model.interfaces.Trackable;

/**
 * The abstract class of trackable
 */
public abstract class AbstractTrackable extends AbstractUnique implements Trackable {
    protected int id;
    protected String name;
    protected String description;
    protected String webSiteUrl;
    protected String category;
    protected String image;

    public AbstractTrackable() {
        id = getUniqueIntId();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (intIdSet.add(id)) {
            intIdSet.remove(this.id);
            this.id = id;
        } else throw new IllegalArgumentException("This id has existed.");
    }

    public String getIdString() {
        return String.valueOf(id);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getWebSiteUrl() {
        return webSiteUrl;
    }

    public void setWebSiteUrl(String webSiteUrl) {
        this.webSiteUrl = webSiteUrl;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return String.format(Locale.getDefault(),
                "ID: %d\nName: %s\nCategory: %s\nWeb Site: %s\nDescription: %s",
                id, name, category, webSiteUrl, description);
    }
}
