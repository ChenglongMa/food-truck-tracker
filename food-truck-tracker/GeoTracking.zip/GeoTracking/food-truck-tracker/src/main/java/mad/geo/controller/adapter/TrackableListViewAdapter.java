package mad.geo.controller.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import mad.geo.R;
import mad.geo.controller.fragment.TrackableFragment;
import mad.geo.model.AbstractTrackable;
import mad.geo.controller.activity.TrackableDetailActivity;
import mad.geo.controller.fragment.TrackableDetailFragment;
import mad.geo.service.TrackableService;

/**
 * The data adapter for trackable list
 */
public class TrackableListViewAdapter
        extends RecyclerView.Adapter<TrackableListViewAdapter.ViewHolder> {
    private static final String LOG_TAG = TrackableListViewAdapter.class.getName();
    private List<AbstractTrackable> mValues;
    private AbstractTrackable selectedTrackable;
    private TrackableService trackableService;


    private TrackableListViewAdapter(List<AbstractTrackable> items) {
        mValues = items;
    }

    public static TrackableListViewAdapter getSingletonInstance(List<AbstractTrackable> items) {
        return LazyHolder.getINSTANCE(items);
    }

    /**
     * Remove the selected item from the data set.
     */
    public void removeSelectedItem() {
        int index = mValues.indexOf(selectedTrackable);
        trackableService.removeTrackable(selectedTrackable);
        notifyChanged();
        notifyItemRemoved(index);
    }

    public void addItem(AbstractTrackable trackable) {
        trackableService.addTrackable(trackable);
        notifyChanged();
        notifyItemInserted(mValues.indexOf(trackable));
    }

    public AbstractTrackable getSelectItem() {
        return selectedTrackable;
    }

    public void editItem(AbstractTrackable trackable) {
        trackableService.updateTrackable(trackable);
        notifyChanged();
        notifyItemChanged(mValues.indexOf(trackable));

    }

    /**
     * Update the data set and notify the UI
     */
    private void notifyChanged() {
        mValues = trackableService.getTrackables();
        notifyDataSetChanged();
    }

    private static class LazyHolder {
        static TrackableListViewAdapter getINSTANCE(List<AbstractTrackable> items) {
            return new TrackableListViewAdapter(items);
        }
    }

    /**
     * Assign the filtered data set to UI
     * @param dataSet
     */
    public void filterDataSet(List<AbstractTrackable> dataSet) {
        mValues = dataSet;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.trackable_list_content, parent, false);
        trackableService = TrackableService.getSingletonInstance(view.getContext());
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        holder.mIdView.setText(mValues.get(position).getIdString());
        holder.mNameView.setText(mValues.get(position).getName());
        holder.mCategory.setText(mValues.get(position).getCategory());
        holder.itemView.setTag(mValues.get(position));
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder
            implements View.OnLongClickListener, View.OnClickListener {
        final TextView mIdView;
        final TextView mNameView;
        final TextView mCategory;


        ViewHolder(View view) {
            super(view);
            mIdView = (TextView) view.findViewById(R.id.item_id);
            mNameView = (TextView) view.findViewById(R.id.item_name);
            mCategory = (TextView) view.findViewById(R.id.item_category);
            view.setOnClickListener(this);
            view.setOnLongClickListener(this);

        }

        @Override
        public void onClick(View view) {
            selectedTrackable = (AbstractTrackable) view.getTag();
            Context context = view.getContext();
            Intent intent = new Intent(context, TrackableDetailActivity.class);
            intent.putExtra(TrackableDetailFragment.TRACKABLE_ID, selectedTrackable.getId());
            context.startActivity(intent);
        }

        @Override
        public boolean onLongClick(View view) {
            selectedTrackable = (AbstractTrackable) view.getTag();
            return false;
        }
    }
}
