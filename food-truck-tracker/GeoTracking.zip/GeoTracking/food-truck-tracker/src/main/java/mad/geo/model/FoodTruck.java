package mad.geo.model;

/**
 * The concrete class of trackable
 */
public class FoodTruck extends AbstractTrackable {

}
