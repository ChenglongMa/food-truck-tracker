package mad.geo.model.interfaces;

/**
 * The tracking interface
 */
public interface Tracking {


}
