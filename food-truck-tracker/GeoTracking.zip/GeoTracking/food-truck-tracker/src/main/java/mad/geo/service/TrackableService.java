package mad.geo.service;

import android.content.Context;
import android.content.res.Resources;
import android.util.Log;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Scanner;

import mad.geo.R;
import mad.geo.model.AbstractTrackable;
import mad.geo.model.AbstractTracking;
import mad.geo.model.FoodTruck;
import mad.geo.model.MealEvent;

/**
 * The trackable service to access data
 */
public class TrackableService {
    /**
     * The filter to get all instances
     */
    public static final String FILTER_ALL = "All";
    private static final String LOG_TAG = TrackableService.class.getName();
    private static Context context;
    private final TrackingService trackingService = TrackingService.getSingletonInstance(context);
    private List<AbstractTrackable> trackables = new ArrayList<>();
    private List<TrackingService.TrackingInfo> trackingInfos = new ArrayList<>();
    private List<AbstractTracking> trackings = new ArrayList<>();

    private TrackableService() {
    }

    /**
     * Advance the date in specific mins
     * @param date
     * @param mins
     * @return
     */
    public static Date advancedDate(Date date, int mins) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + mins);
        return calendar.getTime();
    }

    /**
     * Convert the date to string
     * @param date
     * @return
     */
    public static String dateToString(Date date) {
        return DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM, Locale.getDefault()).format(date);
    }

    public static TrackableService getSingletonInstance(Context context) {
        TrackableService.context = context;
        return LazyHolder.INSTANCE;
    }

    /**
     * Get the Food Truck information from the data source
     * @return
     */
    private static List<AbstractTrackable> parseFoodTruck() {
        List<AbstractTrackable> res = new ArrayList<>();
        try (Scanner scanner = new Scanner(context.getResources().openRawResource(R.raw.food_truck_data))) {
            // match comma and 0 or more whitespace OR trailing space and newline
            scanner.useDelimiter("\"?\\s*,\\s*\"|\"\\s*\\n+");
            while (scanner.hasNext()) {
                AbstractTrackable trackable = new FoodTruck();
                trackable.setId(scanner.nextInt());
                trackable.setName(scanner.next());
                trackable.setDescription(scanner.next());
                trackable.setWebSiteUrl(scanner.next());
                trackable.setCategory(scanner.next());
                res.add(trackable);
            }
        } catch (Resources.NotFoundException e) {
            Log.i(LOG_TAG, "File Not Found Exception Caught");
        }
        return res;
    }

    /**
     * Get End Time information by trackable
     * @param trackable
     * @return
     */
    public List<String> getEndTimes(AbstractTrackable trackable) {
        List<String> times = new ArrayList<>();
        for (TrackingService.TrackingInfo info : getTrackingInfo(trackable)) {
            String endTime = dateToString(advancedDate(info.date, info.stopTime));
            times.add(endTime);
        }
        return times;
    }

    /**
     * Get location information by trackable
     * @param trackable
     * @return
     */
    public List<String> getLocations(AbstractTrackable trackable) {
        List<String> locations = new ArrayList<>();
        for (TrackingService.TrackingInfo tracking : getTrackingInfo(trackable)) {
            if (tracking.stopTime > 0) {
                String location = String.format(Locale.getDefault(), "%f, %f", tracking.latitude, tracking.longitude);
                locations.add(location);
            }
        }
        return locations;
    }

    /**
     * Get Start Time information by trackable
     * @param trackable
     * @return
     */
    public List<String> getStartTimes(AbstractTrackable trackable) {
        List<String> times = new ArrayList<>();
        for (TrackingService.TrackingInfo info : getTrackingInfo(trackable)) {
            String startTime = dateToString(info.date);
            times.add(startTime);
        }
        return times;
    }

    public List<TrackingService.TrackingInfo> getTrackingInfo(AbstractTrackable trackable) {
        List<TrackingService.TrackingInfo> infos = new ArrayList<>();
        parseTrackingData();
        for (TrackingService.TrackingInfo tracking : trackingInfos) {
            if (tracking.trackableId != trackable.getId()) {
                continue;
            }
            infos.add(tracking);
        }
        return infos;
    }

    /**
     * Filter the tracking info by {@link AbstractTrackable} and location
     *
     * @param trackable
     * @param location
     * @return
     */
    public List<String> getStartTimes(AbstractTrackable trackable, String location) {
        List<String> times = new ArrayList<>();
        String[] locations = location.split(",");
        for (TrackingService.TrackingInfo tracking : getTrackingInfo(trackable)) {
            if (tracking.latitude == Double.parseDouble(locations[0]) && tracking.longitude == Double.parseDouble(locations[1])) {
                String startTime = dateToString(tracking.date);
                times.add(startTime);
            }
        }
        return times;
    }
    /**
     * Filter the tracking info by {@link AbstractTrackable} and location
     *
     * @param trackable
     * @param location
     * @return
     */
    public List<String> getEndTimes(AbstractTrackable trackable, String location) {
        List<String> times = new ArrayList<>();
        String[] locations = location.split(",");
        for (TrackingService.TrackingInfo tracking : getTrackingInfo(trackable)) {
            if (tracking.latitude == Double.parseDouble(locations[0]) && tracking.longitude == Double.parseDouble(locations[1])) {
                String endTime = dateToString(advancedDate(tracking.date, tracking.stopTime));
                times.add(endTime);
            }
        }
        return times;
    }

    public List<AbstractTrackable> getTrackables() {
        return trackables;
    }

    public List<AbstractTracking> getTrackings() {
        trackings.sort(new Comparator<AbstractTracking>() {
            @Override
            public int compare(AbstractTracking t1, AbstractTracking t2) {
                return t1.getMeetTime().compareTo(t2.getMeetTime());
            }
        });
        return trackings;
    }

    public void updateTracking(AbstractTracking tracking) {
        for (int i = trackings.size() - 1; i >= 0; i--) {
            if (Objects.equals(trackings.get(i).getTrackingId(), tracking.getTrackingId())) {
                trackings.remove(i);
                trackings.add(i, tracking);
                break;
            }
        }
    }

    public void removeTracking(AbstractTracking tracking) {
        trackings.remove(tracking);
    }

    public void addTracking(AbstractTracking tracking) {
        for (AbstractTracking t : trackings) {
            if (Objects.equals(t.getTrackingId(), tracking.getTrackingId())) {
                throw new IllegalArgumentException("This object has existed");
            }
        }
        trackings.add(tracking);
    }

    private void parseTrackingData() {
        try {
            DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM);
            String searchDate = "05/07/2018 1:00:00 PM";
            int searchWindow = 24 * 60;
            Date date = dateFormat.parse(searchDate);
            trackingInfos = trackingService.getTrackingInfoForTimeRange(date, searchWindow, 0);
        } catch (ParseException e) {
            Log.i(LOG_TAG, "ParseException Caught (Incorrect File Format)");
        }
    }

    public AbstractTrackable getTrackableById(final int id) {
        for (AbstractTrackable trackable : trackables) {
            if (trackable.getId() == id) {
                return trackable;
            }
        }
        return null;
    }

    public List<AbstractTrackable> getInitialTrackables() {
        if (trackables == null || trackables.isEmpty()) {
            trackables = parseFoodTruck();
        }
        return trackables;
    }

    public List<AbstractTrackable> getTrackablesByCategory(final String... cates) {
        if (cates == null || cates.length <= 0 || Arrays.asList(cates).contains(FILTER_ALL)) {
            return getInitialTrackables();
        }
        List<AbstractTrackable> res = new ArrayList<>();
        List<String> cons = Arrays.asList(cates);
        for (AbstractTrackable trackable : trackables) {
            if (cons.contains(trackable.getCategory())) {
                res.add(trackable);
            }
        }
        return res;
    }

    public void addTrackable(AbstractTrackable trackable) {
        for (AbstractTrackable t : trackables) {
            if (t.getId() == trackable.getId()) {
                throw new IllegalArgumentException("This object has existed");
            }
        }
        trackables.add(trackable);
    }

    public void updateTrackable(AbstractTrackable trackable) {
        for (int i = trackables.size() - 1; i >= 0; i--) {
            if (trackables.get(i).getId() == trackable.getId()) {
                trackables.remove(i);
                trackables.add(i, trackable);
                break;
            }
        }
    }

    public void removeTrackable(AbstractTrackable trackable) {
        trackables.remove(trackable);
    }

    public String getRouteInfo(AbstractTrackable trackable) {
        parseTrackingData();
        StringBuilder info = new StringBuilder();
        for (TrackingService.TrackingInfo tracking : trackingInfos) {
            if (tracking.trackableId == trackable.getId()) {
                String r = String.format(Locale.getDefault(),
                        "Location:%.5f,%.5f\tDate/Time:%s\tDuration:%s mins\n\n",
                        tracking.latitude, tracking.longitude,
                        DateFormat.getDateTimeInstance(
                                DateFormat.SHORT, DateFormat.MEDIUM).format(tracking.date), tracking.stopTime);
                info.append(r);
            }
        }
        String res = info.toString();
        return res.isEmpty() ? "No route information now" : res;//TODO
    }

    private static class LazyHolder {
        static final TrackableService INSTANCE = new TrackableService();
    }

    public static class DummyData {
        public static List<AbstractTracking> getDummyTrackings() {
            for (int i = 1; i < 4; i++) {
                AbstractTracking tracking = new MealEvent();
                tracking.setTitle("Lunch at Fat Ribs " + i);
                tracking.setTarStartTime(new Date(System.currentTimeMillis() - 10000000 * i));
                tracking.setTarEndTime(new Date(System.currentTimeMillis() + 10000000 * i));
                tracking.setMeetTime(new Date(System.currentTimeMillis() + 5000000 * i));
                tracking.setTrackableId(i);
                tracking.setCurrLocation("-37.810045, 144.964220");
                tracking.setMeetLocation("-37.810045, 144.964220");
                TrackableService.getSingletonInstance(context).trackings.add(tracking);
            }
            return TrackableService.getSingletonInstance(context).trackings;
        }
    }
}
